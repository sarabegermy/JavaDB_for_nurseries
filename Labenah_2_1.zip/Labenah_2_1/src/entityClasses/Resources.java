/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entityClasses;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author levovo
 */
@Entity
@Table(name = "RESOURCES")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Resources.findAll", query = "SELECT r FROM Resources r"),
    @NamedQuery(name = "Resources.findById", query = "SELECT r FROM Resources r WHERE r.id = :id"),
    @NamedQuery(name = "Resources.findByAddDate", query = "SELECT r FROM Resources r WHERE r.addDate = :addDate"),
    @NamedQuery(name = "Resources.findByName", query = "SELECT r FROM Resources r WHERE r.name = :name"),
    @NamedQuery(name = "Resources.findByNotes", query = "SELECT r FROM Resources r WHERE r.notes = :notes"),
    @NamedQuery(name = "Resources.findByQuantity", query = "SELECT r FROM Resources r WHERE r.quantity = :quantity")})
public class Resources implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "ADD_DATE")
    @Temporal(TemporalType.DATE)
    private Date addDate;
    @Column(name = "NAME")
    private String name;
    @Column(name = "NOTES")
    private String notes;
    @Basic(optional = false)
    @Column(name = "QUANTITY")
    private int quantity;
    @JoinColumn(name = "ORIGINAL_PLACE_ID", referencedColumnName = "ID")
    @ManyToOne
    private PlacesStorage originalPlaceId;
    @JoinColumn(name = "TYPE_ID", referencedColumnName = "ID")
    @ManyToOne
    private Typeofresource typeId;
    @OneToMany(mappedBy = "resourceId")
    private Collection<Route> routeCollection;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "resources")
    private Nonreusableresources nonreusableresources;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "resources")
    private Reusableresources reusableresources;

    public Resources() {
    }

    public Resources(Integer id) {
        this.id = id;
    }

    public Resources(Integer id, int quantity) {
        this.id = id;
        this.quantity = quantity;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public PlacesStorage getOriginalPlaceId() {
        return originalPlaceId;
    }

    public void setOriginalPlaceId(PlacesStorage originalPlaceId) {
        this.originalPlaceId = originalPlaceId;
    }

    public Typeofresource getTypeId() {
        return typeId;
    }

    public void setTypeId(Typeofresource typeId) {
        this.typeId = typeId;
    }

    @XmlTransient
    public Collection<Route> getRouteCollection() {
        return routeCollection;
    }

    public void setRouteCollection(Collection<Route> routeCollection) {
        this.routeCollection = routeCollection;
    }

    public Nonreusableresources getNonreusableresources() {
        return nonreusableresources;
    }

    public void setNonreusableresources(Nonreusableresources nonreusableresources) {
        this.nonreusableresources = nonreusableresources;
    }

    public Reusableresources getReusableresources() {
        return reusableresources;
    }

    public void setReusableresources(Reusableresources reusableresources) {
        this.reusableresources = reusableresources;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Resources)) {
            return false;
        }
        Resources other = (Resources) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entityClasses.Resources[ id=" + id + " ]";
    }
    
}
