/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entityClasses;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author levovo
 */
@Entity
@Table(name = "ROUTE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Route.findAll", query = "SELECT r FROM Route r"),
    @NamedQuery(name = "Route.findById", query = "SELECT r FROM Route r WHERE r.id = :id"),
    @NamedQuery(name = "Route.findByDateOfMove", query = "SELECT r FROM Route r WHERE r.dateOfMove = :dateOfMove"),
    @NamedQuery(name = "Route.findByNotes", query = "SELECT r FROM Route r WHERE r.notes = :notes")})
public class Route implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "DATE_OF_MOVE")
    @Temporal(TemporalType.DATE)
    private Date dateOfMove;
    @Column(name = "NOTES")
    private String notes;
    @JoinColumn(name = "TO_PLACE_ID_ID", referencedColumnName = "ID")
    @ManyToOne
    private PlacesStorage toPlaceIdId;
    @JoinColumn(name = "FROM_PLACE_ID_ID", referencedColumnName = "ID")
    @ManyToOne
    private PlacesStorage fromPlaceIdId;
    @JoinColumn(name = "RESOURCE_ID", referencedColumnName = "ID")
    @ManyToOne
    private Resources resourceId;
    @JoinColumn(name = "USER_PERSON_ID_ID", referencedColumnName = "ID")
    @ManyToOne
    private Workers userPersonIdId;
    @JoinColumn(name = "STORE_KEEPER_ID_ID", referencedColumnName = "ID")
    @ManyToOne
    private Workers storeKeeperIdId;

    public Route() {
    }

    public Route(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDateOfMove() {
        return dateOfMove;
    }

    public void setDateOfMove(Date dateOfMove) {
        this.dateOfMove = dateOfMove;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public PlacesStorage getToPlaceIdId() {
        return toPlaceIdId;
    }

    public void setToPlaceIdId(PlacesStorage toPlaceIdId) {
        this.toPlaceIdId = toPlaceIdId;
    }

    public PlacesStorage getFromPlaceIdId() {
        return fromPlaceIdId;
    }

    public void setFromPlaceIdId(PlacesStorage fromPlaceIdId) {
        this.fromPlaceIdId = fromPlaceIdId;
    }

    public Resources getResourceId() {
        return resourceId;
    }

    public void setResourceId(Resources resourceId) {
        this.resourceId = resourceId;
    }

    public Workers getUserPersonIdId() {
        return userPersonIdId;
    }

    public void setUserPersonIdId(Workers userPersonIdId) {
        this.userPersonIdId = userPersonIdId;
    }

    public Workers getStoreKeeperIdId() {
        return storeKeeperIdId;
    }

    public void setStoreKeeperIdId(Workers storeKeeperIdId) {
        this.storeKeeperIdId = storeKeeperIdId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Route)) {
            return false;
        }
        Route other = (Route) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entityClasses.Route[ id=" + id + " ]";
    }
    
}
