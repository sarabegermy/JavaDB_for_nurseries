/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entityClasses;

import entityClasses.Arrivalanddeparture;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author levovo
 */
@Entity
@Table(name = "WORKERS", catalog = "", schema = "ADMINISTRATOR")
@NamedQueries({
    @NamedQuery(name = "Workers.findAll", query = "SELECT w FROM Workers w"),
    @NamedQuery(name = "Workers.findById", query = "SELECT w FROM Workers w WHERE w.id = :id"),
    @NamedQuery(name = "Workers.findByAnnualholiday", query = "SELECT w FROM Workers w WHERE w.annualholiday = :annualholiday"),
    @NamedQuery(name = "Workers.findByIllnessholiday", query = "SELECT w FROM Workers w WHERE w.illnessholiday = :illnessholiday"),
    @NamedQuery(name = "Workers.findByName", query = "SELECT w FROM Workers w WHERE w.name = :name"),
    @NamedQuery(name = "Workers.findBySuddenholiday", query = "SELECT w FROM Workers w WHERE w.suddenholiday = :suddenholiday")})
public class Workers implements Serializable {

    @OneToMany(mappedBy = "userPersonIdId")
    private Collection<Route> routeCollection;
    @OneToMany(mappedBy = "storeKeeperIdId")
    private Collection<Route> routeCollection1;

    @OneToMany(mappedBy = "workerId")
    private Collection<Arrivalanddeparture> arrivalanddepartureCollection;

    @Basic(optional = false)
    @Column(name = "DAILYSALARY")
    private float dailysalary;

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "ANNUALHOLIDAY")
    private short annualholiday;
    @Basic(optional = false)
    @Column(name = "ILLNESSHOLIDAY")
    private short illnessholiday;
    @Column(name = "NAME")
    private String name;
    @Basic(optional = false)
    @Column(name = "SUDDENHOLIDAY")
    private short suddenholiday;

    public Workers() {
    }

    public Workers(Integer id) {
        this.id = id;
    }

    public Workers(Integer id, short annualholiday, short illnessholiday, short suddenholiday) {
        this.id = id;
        this.annualholiday = annualholiday;
        this.illnessholiday = illnessholiday;
        this.suddenholiday = suddenholiday;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        Integer oldId = this.id;
        this.id = id;
        changeSupport.firePropertyChange("id", oldId, id);
    }

    public short getAnnualholiday() {
        return annualholiday;
    }

    public void setAnnualholiday(short annualholiday) {
        short oldAnnualholiday = this.annualholiday;
        this.annualholiday = annualholiday;
        changeSupport.firePropertyChange("annualholiday", oldAnnualholiday, annualholiday);
    }

    public short getIllnessholiday() {
        return illnessholiday;
    }

    public void setIllnessholiday(short illnessholiday) {
        short oldIllnessholiday = this.illnessholiday;
        this.illnessholiday = illnessholiday;
        changeSupport.firePropertyChange("illnessholiday", oldIllnessholiday, illnessholiday);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        String oldName = this.name;
        this.name = name;
        changeSupport.firePropertyChange("name", oldName, name);
    }

    public short getSuddenholiday() {
        return suddenholiday;
    }

    public void setSuddenholiday(short suddenholiday) {
        short oldSuddenholiday = this.suddenholiday;
        this.suddenholiday = suddenholiday;
        changeSupport.firePropertyChange("suddenholiday", oldSuddenholiday, suddenholiday);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Workers)) {
            return false;
        }
        Workers other = (Workers) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return name;
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }

    public float getDailysalary() {
        return dailysalary;
    }

    public void setDailysalary(float dailysalary) {
        this.dailysalary = dailysalary;
    }

    @XmlTransient
    public Collection<Arrivalanddeparture> getArrivalanddepartureCollection() {
        return arrivalanddepartureCollection;
    }

    public void setArrivalanddepartureCollection(Collection<Arrivalanddeparture> arrivalanddepartureCollection) {
        this.arrivalanddepartureCollection = arrivalanddepartureCollection;
    }

    @XmlTransient
    public Collection<Route> getRouteCollection() {
        return routeCollection;
    }

    public void setRouteCollection(Collection<Route> routeCollection) {
        this.routeCollection = routeCollection;
    }

    @XmlTransient
    public Collection<Route> getRouteCollection1() {
        return routeCollection1;
    }

    public void setRouteCollection1(Collection<Route> routeCollection1) {
        this.routeCollection1 = routeCollection1;
    }
    
}
