/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entityClasses;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Calendar;
//import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author levovo
 */
@Entity
@Table(name = "ARRIVALANDDEPARTURE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Arrivalanddeparture.findByIdLastEntered", query = "SELECT a FROM Arrivalanddeparture a WHERE a.workerId = :worker_id ORDER BY a.id DESC"),
    @NamedQuery(name = "Arrivalanddeparture.findAll", query = "SELECT a FROM Arrivalanddeparture a"),
    @NamedQuery(name = "Arrivalanddeparture.findById", query = "SELECT a FROM Arrivalanddeparture a WHERE a.id = :id"),
    @NamedQuery(name = "Arrivalanddeparture.findByArrivaltime", query = "SELECT a FROM Arrivalanddeparture a WHERE a.arrivaltime = :arrivaltime"),
    @NamedQuery(name = "Arrivalanddeparture.findByDeparturetime", query = "SELECT a FROM Arrivalanddeparture a WHERE a.departuretime = :departuretime"),
    @NamedQuery(name = "Arrivalanddeparture.findByTodaysalary", query = "SELECT a FROM Arrivalanddeparture a WHERE a.todaysalary = :todaysalary")})
public class Arrivalanddeparture implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Long id;
    @Column(name = "ARRIVALTIME")
    //@Temporal(TemporalType.TIMESTAMP)
    private java.sql.Timestamp arrivaltime;
    @Column(name = "DEPARTURETIME")
    //@Temporal(TemporalType.TIMESTAMP)
    private java.sql.Timestamp departuretime;
    @Column(name = "TODAYSALARY")
    private Float todaysalary;
    @JoinColumn(name = "WORKER_ID", referencedColumnName = "ID")
    @ManyToOne
    private Workers workerId;

    public Arrivalanddeparture() {
    }

    public Arrivalanddeparture(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public java.sql.Timestamp getArrivaltime() {
        return arrivaltime;
    }
//    public boolean isSameArrivalDate(){
//        return (this.arrivaltime.compareTo(Date.valueOf(LocalDate.now())) == 0)? true : false;
//    }
    public void setArrivaltime(java.sql.Timestamp arrivaltime) {
        this.arrivaltime = arrivaltime;
    }

    public java.sql.Timestamp getDeparturetime() {
        return departuretime;
    }

    public void setDeparturetime(java.sql.Timestamp departuretime) {
        this.departuretime = departuretime;
    }

    public Float getTodaysalary() {
        return todaysalary;
    }

    public void setTodaysalary(Float todaysalary) {
        this.todaysalary = todaysalary;
    }

    public Workers getWorkerId() {
        return workerId;
    }

    public void setWorkerId(Workers workerId) {
        this.workerId = workerId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Arrivalanddeparture)) {
            return false;
        }
        Arrivalanddeparture other = (Arrivalanddeparture) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entityClasses.Arrivalanddeparture[ id=" + id + " ]";
    }
    
}
