/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entityClasses;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author levovo
 */
@Entity
@Table(name = "NONREUSABLERESOURCES")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Nonreusableresources.findAll", query = "SELECT n FROM Nonreusableresources n"),
    @NamedQuery(name = "Nonreusableresources.findByThreshold", query = "SELECT n FROM Nonreusableresources n WHERE n.threshold = :threshold"),
    @NamedQuery(name = "Nonreusableresources.findById", query = "SELECT n FROM Nonreusableresources n WHERE n.id = :id")})
public class Nonreusableresources implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "THRESHOLD")
    private int threshold;
    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @JoinColumn(name = "ID", referencedColumnName = "ID", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Resources resources;

    public Nonreusableresources() {
    }

    public Nonreusableresources(Integer id) {
        this.id = id;
    }

    public Nonreusableresources(Integer id, int threshold) {
        this.id = id;
        this.threshold = threshold;
    }

    public int getThreshold() {
        return threshold;
    }

    public void setThreshold(int threshold) {
        this.threshold = threshold;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Resources getResources() {
        return resources;
    }

    public void setResources(Resources resources) {
        this.resources = resources;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Nonreusableresources)) {
            return false;
        }
        Nonreusableresources other = (Nonreusableresources) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entityClasses.Nonreusableresources[ id=" + id + " ]";
    }
    
}
