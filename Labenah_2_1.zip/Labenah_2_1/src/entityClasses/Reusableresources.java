/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entityClasses;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author levovo
 */
@Entity
@Table(name = "REUSABLERESOURCES")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Reusableresources.findAll", query = "SELECT r FROM Reusableresources r"),
    @NamedQuery(name = "Reusableresources.findByCognitive", query = "SELECT r FROM Reusableresources r WHERE r.cognitive = :cognitive"),
    @NamedQuery(name = "Reusableresources.findByDescription", query = "SELECT r FROM Reusableresources r WHERE r.description = :description"),
    @NamedQuery(name = "Reusableresources.findByIsSuitableFor2AndHalfYears", query = "SELECT r FROM Reusableresources r WHERE r.isSuitableFor2AndHalfYears = :isSuitableFor2AndHalfYears"),
    @NamedQuery(name = "Reusableresources.findByIsSuitableFor2Years", query = "SELECT r FROM Reusableresources r WHERE r.isSuitableFor2Years = :isSuitableFor2Years"),
    @NamedQuery(name = "Reusableresources.findByIsSuitableFor3Years", query = "SELECT r FROM Reusableresources r WHERE r.isSuitableFor3Years = :isSuitableFor3Years"),
    @NamedQuery(name = "Reusableresources.findByIsSuitableFor4Years", query = "SELECT r FROM Reusableresources r WHERE r.isSuitableFor4Years = :isSuitableFor4Years"),
    @NamedQuery(name = "Reusableresources.findByIsSuitableForSummerClass", query = "SELECT r FROM Reusableresources r WHERE r.isSuitableForSummerClass = :isSuitableForSummerClass"),
    @NamedQuery(name = "Reusableresources.findByLingual", query = "SELECT r FROM Reusableresources r WHERE r.lingual = :lingual"),
    @NamedQuery(name = "Reusableresources.findByMotorSkills", query = "SELECT r FROM Reusableresources r WHERE r.motorSkills = :motorSkills"),
    @NamedQuery(name = "Reusableresources.findByNeedToGetNew", query = "SELECT r FROM Reusableresources r WHERE r.needToGetNew = :needToGetNew"),
    @NamedQuery(name = "Reusableresources.findByNeedsToBeFixed", query = "SELECT r FROM Reusableresources r WHERE r.needsToBeFixed = :needsToBeFixed"),
    @NamedQuery(name = "Reusableresources.findByReligion", query = "SELECT r FROM Reusableresources r WHERE r.religion = :religion"),
    @NamedQuery(name = "Reusableresources.findBySocial", query = "SELECT r FROM Reusableresources r WHERE r.social = :social"),
    @NamedQuery(name = "Reusableresources.findByWhatNeedsToBeFixed", query = "SELECT r FROM Reusableresources r WHERE r.whatNeedsToBeFixed = :whatNeedsToBeFixed"),
    @NamedQuery(name = "Reusableresources.findById", query = "SELECT r FROM Reusableresources r WHERE r.id = :id")})
public class Reusableresources implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "COGNITIVE")
    private Boolean cognitive;
    @Column(name = "DESCRIPTION")
    private String description;
    @Lob
    @Column(name = "IMAGE")
    private byte[] image;
    @Basic(optional = false)
    @Column(name = "IS_SUITABLE_FOR_2_AND_HALF_YEARS")
    private Boolean isSuitableFor2AndHalfYears;
    @Basic(optional = false)
    @Column(name = "IS_SUITABLE_FOR_2_YEARS")
    private Boolean isSuitableFor2Years;
    @Basic(optional = false)
    @Column(name = "IS_SUITABLE_FOR_3_YEARS")
    private Boolean isSuitableFor3Years;
    @Basic(optional = false)
    @Column(name = "IS_SUITABLE_FOR_4_YEARS")
    private Boolean isSuitableFor4Years;
    @Basic(optional = false)
    @Column(name = "IS_SUITABLE_FOR_SUMMER_CLASS")
    private Boolean isSuitableForSummerClass;
    @Basic(optional = false)
    @Column(name = "LINGUAL")
    private Boolean lingual;
    @Basic(optional = false)
    @Column(name = "MOTOR_SKILLS")
    private Boolean motorSkills;
    @Basic(optional = false)
    @Column(name = "NEED_TO_GET_NEW")
    private Boolean needToGetNew;
    @Basic(optional = false)
    @Column(name = "NEEDS_TO_BE_FIXED")
    private Boolean needsToBeFixed;
    @Basic(optional = false)
    @Column(name = "RELIGION")
    private Boolean religion;
    @Basic(optional = false)
    @Column(name = "SOCIAL")
    private Boolean social;
    @Column(name = "WHAT_NEEDS_TO_BE_FIXED")
    private String whatNeedsToBeFixed;
    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @JoinTable(name = "JOIN_UNITS_RESOURCES", joinColumns = {
        @JoinColumn(name = "RESOURCE_ID", referencedColumnName = "ID")}, inverseJoinColumns = {
        @JoinColumn(name = "UNIT_ID", referencedColumnName = "ID")})
    @ManyToMany
    private Collection<Units> unitsCollection;
    @JoinColumn(name = "ID", referencedColumnName = "ID", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Resources resources;

    public Reusableresources() {
    }

    public Reusableresources(Integer id) {
        this.id = id;
    }

    public Reusableresources(Integer id, Boolean cognitive, Boolean isSuitableFor2AndHalfYears, Boolean isSuitableFor2Years, Boolean isSuitableFor3Years, Boolean isSuitableFor4Years, Boolean isSuitableForSummerClass, Boolean lingual, Boolean motorSkills, Boolean needToGetNew, Boolean needsToBeFixed, Boolean religion, Boolean social) {
        this.id = id;
        this.cognitive = cognitive;
        this.isSuitableFor2AndHalfYears = isSuitableFor2AndHalfYears;
        this.isSuitableFor2Years = isSuitableFor2Years;
        this.isSuitableFor3Years = isSuitableFor3Years;
        this.isSuitableFor4Years = isSuitableFor4Years;
        this.isSuitableForSummerClass = isSuitableForSummerClass;
        this.lingual = lingual;
        this.motorSkills = motorSkills;
        this.needToGetNew = needToGetNew;
        this.needsToBeFixed = needsToBeFixed;
        this.religion = religion;
        this.social = social;
    }

    public Boolean getCognitive() {
        return cognitive;
    }

    public void setCognitive(Boolean cognitive) {
        this.cognitive = cognitive;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public Boolean getIsSuitableFor2AndHalfYears() {
        return isSuitableFor2AndHalfYears;
    }

    public void setIsSuitableFor2AndHalfYears(Boolean isSuitableFor2AndHalfYears) {
        this.isSuitableFor2AndHalfYears = isSuitableFor2AndHalfYears;
    }

    public Boolean getIsSuitableFor2Years() {
        return isSuitableFor2Years;
    }

    public void setIsSuitableFor2Years(Boolean isSuitableFor2Years) {
        this.isSuitableFor2Years = isSuitableFor2Years;
    }

    public Boolean getIsSuitableFor3Years() {
        return isSuitableFor3Years;
    }

    public void setIsSuitableFor3Years(Boolean isSuitableFor3Years) {
        this.isSuitableFor3Years = isSuitableFor3Years;
    }

    public Boolean getIsSuitableFor4Years() {
        return isSuitableFor4Years;
    }

    public void setIsSuitableFor4Years(Boolean isSuitableFor4Years) {
        this.isSuitableFor4Years = isSuitableFor4Years;
    }

    public Boolean getIsSuitableForSummerClass() {
        return isSuitableForSummerClass;
    }

    public void setIsSuitableForSummerClass(Boolean isSuitableForSummerClass) {
        this.isSuitableForSummerClass = isSuitableForSummerClass;
    }

    public Boolean getLingual() {
        return lingual;
    }

    public void setLingual(Boolean lingual) {
        this.lingual = lingual;
    }

    public Boolean getMotorSkills() {
        return motorSkills;
    }

    public void setMotorSkills(Boolean motorSkills) {
        this.motorSkills = motorSkills;
    }

    public Boolean getNeedToGetNew() {
        return needToGetNew;
    }

    public void setNeedToGetNew(Boolean needToGetNew) {
        this.needToGetNew = needToGetNew;
    }

    public Boolean getNeedsToBeFixed() {
        return needsToBeFixed;
    }

    public void setNeedsToBeFixed(Boolean needsToBeFixed) {
        this.needsToBeFixed = needsToBeFixed;
    }

    public Boolean getReligion() {
        return religion;
    }

    public void setReligion(Boolean religion) {
        this.religion = religion;
    }

    public Boolean getSocial() {
        return social;
    }

    public void setSocial(Boolean social) {
        this.social = social;
    }

    public String getWhatNeedsToBeFixed() {
        return whatNeedsToBeFixed;
    }

    public void setWhatNeedsToBeFixed(String whatNeedsToBeFixed) {
        this.whatNeedsToBeFixed = whatNeedsToBeFixed;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @XmlTransient
    public Collection<Units> getUnitsCollection() {
        return unitsCollection;
    }

    public void setUnitsCollection(Collection<Units> unitsCollection) {
        this.unitsCollection = unitsCollection;
    }

    public Resources getResources() {
        return resources;
    }

    public void setResources(Resources resources) {
        this.resources = resources;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reusableresources)) {
            return false;
        }
        Reusableresources other = (Reusableresources) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entityClasses.Reusableresources[ id=" + id + " ]";
    }
    
}
