/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entityClasses;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.swing.tree.DefaultMutableTreeNode;
/**
 *
 * @author levovo
 */
@Entity
@Table(name = "PLACES_STORAGE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PlacesStorage.findAll", query = "SELECT p FROM PlacesStorage p ORDER BY p.path"),
    @NamedQuery(name = "PlacesStorage.findById", query = "SELECT p FROM PlacesStorage p WHERE p.id = :id"),
    @NamedQuery(name = "PlacesStorage.findByPath", query = "SELECT p FROM PlacesStorage p WHERE p.path = :path"),
    @NamedQuery(name = "PlacesStorage.findByPlace", query = "SELECT p FROM PlacesStorage p WHERE p.place = :place")})
public class PlacesStorage extends DefaultMutableTreeNode implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "PATH")
    private String path;
    @Column(name = "PLACE")
    private String place;
    @OneToMany(mappedBy = "biggerplaceId")
    private Collection<PlacesStorage> placesStorageCollection;
    @JoinColumn(name = "BIGGERPLACE_ID", referencedColumnName = "ID")
    @ManyToOne
    private PlacesStorage biggerplaceId;

    public PlacesStorage() {
    }

    public PlacesStorage(Integer id) {
        this.id = id;
    }

//    public PlacesStorage(String s) {
//        //super(s);
//        this.place = s;
//    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPath_() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    @XmlTransient
    public Collection<PlacesStorage> getPlacesStorageCollection() {
        return placesStorageCollection;
    }

    public void setPlacesStorageCollection(Collection<PlacesStorage> placesStorageCollection) {
        this.placesStorageCollection = placesStorageCollection;
    }

    public PlacesStorage getBiggerplaceId() {
        return biggerplaceId;
    }

    public void setBiggerplaceId(PlacesStorage biggerplaceId) {
        this.biggerplaceId = biggerplaceId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PlacesStorage)) {
            return false;
        }
        PlacesStorage other = (PlacesStorage) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        //return "entityClasses.PlacesStorage[ id=" + id + " ]";
        return place;
    }
    
}
