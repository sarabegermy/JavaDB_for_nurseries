/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labenah;

import gui.LabenahMain;



/**
 *
 * @author levovo
 */
public class Main {
    public static void main(String args[]){
//        Configuration config = new Configuration();
//        config.addAnnotatedClass(persistence.ArrivalAndDeparture.class);
//        config.configure();
        new LabenahMain().setVisible(true);
    }
}
